package cambiarWhile;

public class CambiarWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 0;

		do {
			i += 1;
			System.out.printf("Iteraci�n %d\n", i);

		} while (i < 50);
	}

}
